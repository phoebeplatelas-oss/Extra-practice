function skin(button) {
    if (button.id === "light") {
        document.getElementById("character").src =
            "https://raw.githubusercontent.com/phoebeplatelas-oss/Extra-practice/main/Drawing-10.sketchpad.png";
    }
  if (button.id === "medlight") {
        document.getElementById("character").src =
            "https://raw.githubusercontent.com/phoebeplatelas-oss/Extra-practice/main/Drawing-10.sketchpad (1).png";
    }
  if (button.id === "meddark") {
        document.getElementById("character").src =
            "https://raw.githubusercontent.com/phoebeplatelas-oss/Extra-practice/main/Drawing-10.sketchpad (2).png";
    }
   if (button.id === "dark") {
        document.getElementById("character").src =
            "https://raw.githubusercontent.com/phoebeplatelas-oss/Extra-practice/main/Drawing-10.sketchpad (3).png";
    }
}
 
const canvas = document.getElementById("drawingCanvas");
const ctx = canvas.getContext("2d");
let drawing = false;

canvas.addEventListener("pointerdown", startDrawing);
canvas.addEventListener("pointermove", draw);
canvas.addEventListener("pointerup", stopDrawing);
canvas.addEventListener("pointerleave", stopDrawing);

function startDrawing(event) {
    drawing = true;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
}

function draw(event) {
    if (!drawing) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    ctx.lineWidth = 5;
    ctx.lineCap = "round";

    ctx.lineTo(x, y);
    ctx.stroke();
}

function stopDrawing() {
    drawing = false;
    ctx.beginPath();
}
function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}
function draw(event) {
  if (!drawing) return;

  ctx.strokeStyle = document.getElementById("colorPicker").value;
  ctx.lineWidth = 5;
  ctx.lineCap = "round";

  ctx.lineTo(event.offsetX, event.offsetY);
  ctx.stroke();
}

function save(area) {
  const canvas = document.getElementById("drawingCanvas");
  const img = canvas.toDataURL("image/png");
  const nailprint = document.createElement("img");
  nailprint.src = canvas.toDataURL("image/png");
  nailprint.style.position = "absolute";
  
  nailprint.style.width ="40px";
  nailprint.style.height ="70px";
  nailprint.style.zIndex = "10";

  if (area.id === "1") {
    
    nailprint.style.left = "55px";
    nailprint.style.top = "135px";
    
  }

  if (area.id === "2") {
    nailprint.style.left = "150px";
    nailprint.style.top = "65px";
  }

  if (area.id === "3") {
    nailprint.style.left = "185px";
    nailprint.style.top = "60px";
  }

  if (area.id === "4") {
    nailprint.style.left = "290px";
    nailprint.style.top = "105px";
  }

  if (area.id === "5") {
    nailprint.style.left = "380px";
    nailprint.style.top = "300px";
  }
  document.getElementById("hand").appendChild(nailprint);
}